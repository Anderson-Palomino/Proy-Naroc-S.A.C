document.addEventListener('DOMContentLoaded', function() {
    alert('Bienvenido a Naroc S.A.C.');
});